#include "utility.h"
#include <pcl/ModelCoefficients.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/features/normal_3d.h>
#include <pcl/search/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>

std::string subObstacle,pubCluster;
class obstacle_env {
private:
    ros::NodeHandle nh;
    ros::NodeHandlePtr pnh;
public:

    ros::Subscriber subobject;
    ros::Publisher pubObstacle;


    obstacle_env(){

        //pnh->param<std::string>("subObstacle", subObstacle, "subObstacle");
        //pnh->param<std::string>("pubcluster", pubCluster, "pubcluster");


        subobject = nh.subscribe<sensor_msgs::PointCloud2>("/lidar_pcl/obstacle", 5, &obstacle_env::clustering_points, this);
        pubObstacle = nh.advertise<sensor_msgs::PointCloud2> ("/lidar_pcl/cluster" , 10);
    }



    void clustering_points(const sensor_msgs::PointCloud2ConstPtr& total_msg) {
      clock_t start, finish;
       double duration;
      start = clock();
    pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object_1 (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object_3 (new pcl::PointCloud<pcl::PointXYZI> ());
      sensor_msgs::PointCloud2 pubclustermsg;
      pcl::fromROSMsg(*total_msg, *pcl_object_1);
      pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_object_2 (new pcl::PointCloud<pcl::PointXYZ> ());

      pcl::PassThrough<pcl::PointXYZI> boxfilter;
      boxfilter.setInputCloud (pcl_object_1);
      boxfilter.setFilterFieldName ("y");
      boxfilter.setFilterLimits (-10.0, 10.0);
      boxfilter.filter (*pcl_object_3);


      pcl::PassThrough<pcl::PointXYZI> pass;
      pass.setInputCloud (pcl_object_3);                //입력
      pass.setFilterFieldName ("z");             //적용할 좌표 축 (eg. Z축)
      pass.setFilterLimits(-0.4, 0.6);          //적용할 값 (최소, 최대 값)

      pass.setNegative(true);
      pass.filter(*pcl_object);



      copyPointCloud(*pcl_object, *pcl_object_2);


////////// clustering
      pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_f (new pcl::PointCloud<pcl::PointXYZI>);
      std::cout << "PointCloud before filtering has: " << pcl_object->size () << " data points." << std::endl; //*


      // Creating the KdTree object for the search method of the extraction
      pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ>);
      tree->setInputCloud (pcl_object_2);

      std::vector<pcl::PointIndices> cluster_indices;
      pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
      ec.setClusterTolerance (0.4); // 20cm
      ec.setMinClusterSize (50);
      ec.setMaxClusterSize (1000);
      ec.setSearchMethod (tree);
      ec.setInputCloud (pcl_object_2);
      ec.extract (cluster_indices);
      pcl::PointCloud<pcl::PointXYZI>::Ptr object_clustered (new pcl::PointCloud<pcl::PointXYZI> ());
      int j = 1;
      for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it)
      {
        for(std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit){
            pcl::PointXYZ pt = pcl_object_2->points[*pit];
            pcl::PointXYZI pt2;
             pcl::PointXYZI minPt, maxPt;
            pcl::PointCloud<pcl::PointXYZI>::Ptr cluster_num (new pcl::PointCloud<pcl::PointXYZI> ());
            pt2.x=pt.x, pt2.y=pt.y, pt2.z=pt.z;
            pt2.intensity=(float)(j);


            cluster_num->points.push_back(pt2);
            pcl::getMinMax3D (*cluster_num, minPt, maxPt);


            *object_clustered += *cluster_num;
        }
        j++;
      }

//////// clustering
      pcl::toROSMsg(*object_clustered, pubclustermsg);
      pubclustermsg.header.frame_id = "vehicle_frame";
      pubObstacle.publish(pubclustermsg);

      finish = clock();
      duration = (double)(finish - start) / CLOCKS_PER_SEC;
      cout << "RANSAC done. " << setprecision(5) << duration << "s"<< endl;

    }


};


int main(int argc, char** argv)
{
    ros::init(argc, argv, "obstacleseg_node");

    obstacle_env obstacle_filter;

    ROS_INFO("\033[1;32m----> [AGV Global Module] : Image Projection / MIDDLE LIDAR\033[0m");

    ros::MultiThreadedSpinner spinner(3);
    spinner.spin();

    return 0;
}


//sources ~/workspace/pharos_ws/devel/setup.bash
