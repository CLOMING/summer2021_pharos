#include "utility.h"
#include <pcl/ModelCoefficients.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/io/pcd_io.h>

/***********************************************************
This file does time synchronization between lidar data
and filter the near surface and others which is above ground.
From obtained groud pointcloud data, apply RANSAC algorithm.
***********************************************************/

std::string subTransformedLeftTopic, subTransformedRightTopic, subTransformedTopTopic;
std::string pubTotalLidar, pubSurface, pubObstacle;
float zSurface, zBoundary;

class LidarSegmentation {
private:
    ros::NodeHandle nh; 
    ros::NodeHandlePtr pnh;
    
public:
    ros::Subscriber subLaserCloudInfo;
    ros::Publisher pubCombined;
    ros::Publisher pubGround;
    ros::Publisher pubObject;
    
    pcl::PointCloud<pcl::PointXYZI>::Ptr fusedCloud;
    sensor_msgs::PointCloud2 pubFusedsensor;

    LidarSegmentation(){
      pnh = ros::NodeHandlePtr(new ros::NodeHandle("~"));
      
      pnh->param<std::string>("subTransformedLeftTopic", subTransformedLeftTopic, "subTransformedLeftTopic");
      pnh->param<std::string>("subTransformedRightTopic", subTransformedRightTopic, "subTransformedRightTopic");
      pnh->param<std::string>("subTransformedTopTopic", subTransformedTopTopic, "subTransformedTopTopic");
      pnh->param<std::string>("pubTotalLidar", pubTotalLidar, "pubTotalLidar");
      pnh->param<std::string>("pubSurface", pubSurface, "pubSurface");
      pnh->param<std::string>("pubObstacle", pubObstacle, "pubObstacle");
      
      pnh->param<float>("zSurface", zSurface, 0.0);
      pnh->param<float>("zBoundary", zBoundary, 0.0);
    
      // Time synchronization between two lidars
      typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::PointCloud2, sensor_msgs::PointCloud2, sensor_msgs::PointCloud2> SyncPolicy;
      message_filters::Subscriber<sensor_msgs::PointCloud2> *sub1_, *sub2_, *sub3_;
      message_filters::Synchronizer<SyncPolicy>* sync_;
      sub1_ = new message_filters::Subscriber<sensor_msgs::PointCloud2>(nh, subTransformedLeftTopic, 1);
      sub2_ = new message_filters::Subscriber<sensor_msgs::PointCloud2>(nh, subTransformedRightTopic, 1);
      sub3_ = new message_filters::Subscriber<sensor_msgs::PointCloud2>(nh, subTransformedTopTopic, 1);
      sync_ = new message_filters::Synchronizer<SyncPolicy>(SyncPolicy(10), *sub1_, *sub2_, *sub3_);
      
      sync_->registerCallback(boost::bind(&LidarSegmentation::combineLidars, this, _1, _2, _3));
      
      pubCombined = nh.advertise<sensor_msgs::PointCloud2> (pubTotalLidar, 10);
      pubGround = nh.advertise<sensor_msgs::PointCloud2> (pubSurface, 10);
      pubObject = nh.advertise<sensor_msgs::PointCloud2> (pubObstacle, 10);
    }


    void detectSurfacePoints(const sensor_msgs::PointCloud2ConstPtr& total_msg) {
      /* 
      input: time synchronized and integrated lidar data
      separates pointclouds on surface and the points above surface as obstacle
      */
      
      //clock_t time = clock();
      
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_total (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_total_2 (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_plane (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object_1 (new pcl::PointCloud<pcl::PointXYZI> ());
      // get points satisfying zLower < z < zUpper       
      pcl::PointCloud<pcl::PointXYZI>::Ptr ground_cand(new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr non_ground(new pcl::PointCloud<pcl::PointXYZI> ());
            
      pcl::fromROSMsg(*total_msg, *pcl_total);

      pcl::CropBox<pcl::PointXYZI> boxFilter;
      boxFilter.setMin(Eigen::Vector4f(-1, -1.5, 0, 1.0));
      boxFilter.setMax(Eigen::Vector4f(4, 1.5, 2.5, 1.0));
      boxFilter.setInputCloud(pcl_total);
      boxFilter.setNegative(true);
      boxFilter.filter(*pcl_total_2);
      
     



      pcl::PassThrough<pcl::PointXYZI> pass;
      pass.setInputCloud (pcl_total_2);                //입력
      pass.setFilterFieldName ("z");             //적용할 좌표 축 (eg. Z축)
      pass.setFilterLimits(zSurface-zBoundary, zSurface+zBoundary);          //적용할 값 (최소, 최대 값)
      pass.filter(*ground_cand);
      
      pass.setNegative(true);
      pass.filter(*non_ground);
      
      // RANSAC - get indices of inliers
      pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients);
      pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
      pcl::SACSegmentation<pcl::PointXYZI> seg;
      
      seg.setOptimizeCoefficients (true);
      seg.setModelType (pcl::SACMODEL_PLANE);
      seg.setMethodType (pcl::SAC_RANSAC);
      seg.setDistanceThreshold (0.2);
      seg.setInputCloud (ground_cand);
      seg.segment (*inliers, *coefficients);
      
      // filter inliers among ground candidates
      pcl::copyPointCloud<pcl::PointXYZI>(*ground_cand, *inliers, *pcl_plane);
      
      // ground candidates but outliers
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_outlier (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::ExtractIndices<pcl::PointXYZI> extract;
      
      extract.setInputCloud(ground_cand);
      extract.setIndices(inliers);
      extract.setNegative(true);
      extract.filter(*pcl_outlier);
       
      // obtain object pointclouds
      *pcl_object += *non_ground;
      *pcl_object += *pcl_outlier;

      pcl::PassThrough<pcl::PointXYZI> boxfilterNEW;
      boxfilterNEW.setInputCloud (pcl_object);
      boxfilterNEW.setFilterFieldName ("y");
      boxfilterNEW.setFilterLimits (-10.0, 10.0);
      boxfilterNEW.filter (*pcl_object_1);
      
      
      sensor_msgs::PointCloud2 pubGroundMsg;
      sensor_msgs::PointCloud2 pubObjectMsg;
      
      pcl::toROSMsg(*pcl_object_1, pubObjectMsg);
      pubObjectMsg.header.frame_id = "vehicle_frame";
      pubObject.publish(pubObjectMsg);
      
      pcl::toROSMsg(*pcl_plane, pubGroundMsg);
      pubGroundMsg.header.frame_id = "vehicle_frame";
      pubGround.publish(pubGroundMsg);
      
      //double duration = (double)(time / CLOCKS_PER_SEC);
      //cout << "RANSAC done. " << setprecision(5) << duration << "s"<< endl;
    }

    void combineLidars(const sensor_msgs::PointCloud2ConstPtr& LeftPC, const sensor_msgs::PointCloud2ConstPtr& RightPC, const sensor_msgs::PointCloud2ConstPtr& TopPC) {        
        /*
        This function is callbacked after synchronization.
        It combines two input lidars and call detect ground points
        */
        pcl::PointCloud<pcl::PointXYZI>::Ptr fusedCloud (new pcl::PointCloud<pcl::PointXYZI> ());
        //pcl::PointCloud<pcl::PointXYZI>::Ptr pclL (new pcl::PointCloud<pcl::PointXYZI> ());
        //pcl::PointCloud<pcl::PointXYZI>::Ptr pclR (new pcl::PointCloud<pcl::PointXYZI> ());
        pcl::PointCloud<pcl::PointXYZI>::Ptr pclT (new pcl::PointCloud<pcl::PointXYZI> ());
        
       // pcl::fromROSMsg(*LeftPC, *pclL);
       // pcl::fromROSMsg(*RightPC, *pclR);
        pcl::fromROSMsg(*TopPC, *pclT);
        fusedCloud->clear();
        //*fusedCloud += *pclL;
        //*fusedCloud += *pclR;
        *fusedCloud += *pclT;

        pcl::toROSMsg(*fusedCloud, pubFusedsensor);
        pubFusedsensor.header.frame_id = "vehicle_frame";
        pubCombined.publish(pubFusedsensor);
        
        const sensor_msgs::PointCloud2ConstPtr& Fusedcloud_ptr = boost::make_shared<sensor_msgs::PointCloud2>(pubFusedsensor);
        detectSurfacePoints(Fusedcloud_ptr);
    }
};


int main(int argc, char** argv)
{
    ros::init(argc, argv, "lidarseg_node");

    LidarSegmentation lidarseg;

    ROS_INFO("\033[1;32m----> [AGV Global Module] : Image Projection / MIDDLE LIDAR\033[0m");

    ros::MultiThreadedSpinner spinner(3);
    spinner.spin();

    return 0;
}
