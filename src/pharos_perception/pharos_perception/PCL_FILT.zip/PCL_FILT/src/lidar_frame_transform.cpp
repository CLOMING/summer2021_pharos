#include "utility.h"

/*************************************************
This script subscribes three velodyne poincloud,
transforms poincloud into vehicle frame,
and publish 
**************************************************/

using namespace std;

int velLeft2CapFrameNum, velTop2CapFrameNum, velRight2CapFrameNum, cap2VehFrameNum;
std::string subLeftTopic, subTopTopic, subRightTopic, pubLeftTopic, pubTopTopic,pubRightTopic;

class LidarTransform {
private:
  ros::NodeHandle nh;
  ros::NodeHandlePtr pnh;

public: 
  ros::Subscriber subTop;
  ros::Subscriber subLeft;
  ros::Subscriber subRight;
  ros::Publisher pubTop;
  ros::Publisher pubLeft;
  ros::Publisher pubRight;
  sensor_msgs::PointCloud2 pubTsensor;
  sensor_msgs::PointCloud2 pubLsensor;
  sensor_msgs::PointCloud2 pubRsensor;
  Eigen::Affine3f transLeftToVeh;
  Eigen::Affine3f transRightToVeh;
  Eigen::Affine3f transTopToVeh;
  Eigen::Matrix4f M_for_l;
  Eigen::Matrix4f M_for_r;
  Eigen::Matrix4f M_for_t;


  ros::Publisher pubPointCloud;
  ros::Publisher pubCombine;

    LidarTransform() {
      // set parameter values through launch file
      pnh = ros::NodeHandlePtr(new ros::NodeHandle("~"));
      
      pnh->param<int>("velLeft2CapFrameNum", velLeft2CapFrameNum, 0);
      pnh->param<int>("velTop2CapFrameNum", velTop2CapFrameNum, 0);
      pnh->param<int>("velRight2CapFrameNum", velRight2CapFrameNum, 0);
      pnh->param<int>("cap2VehFrameNum", cap2VehFrameNum, 0);
      
      pnh->param<std::string>("subLeftTopic", subLeftTopic, "subLeftTopic");
      pnh->param<std::string>("subTopTopic", subTopTopic, "subTopTopic");
      pnh->param<std::string>("subRightTopic", subRightTopic, "subRightTopic");
      pnh->param<std::string>("pubLeftTopic", pubLeftTopic, "pubLeftTopic");
      pnh->param<std::string>("pubTopTopic", pubTopTopic, "pubTopTopic");
      pnh->param<std::string>("pubRightTopic", pubRightTopic, "pubRightTopic");      
     
      Eigen::Affine3f velodyneL2cap;
      Eigen::Affine3f velodyneR2cap;
      Eigen::Affine3f velodyneT2cap;
      Eigen::Affine3f cap2veh;
      getTransformationMatrix(velLeft2CapFrameNum, &velodyneL2cap);
      getTransformationMatrix(velTop2CapFrameNum, &velodyneT2cap);
      getTransformationMatrix(velRight2CapFrameNum, &velodyneR2cap);
      getTransformationMatrix(cap2VehFrameNum, &cap2veh);
      
      // Transformation matrix of velodyne into vehicle frame
      transLeftToVeh = cap2veh * velodyneL2cap;
      transTopToVeh = cap2veh * velodyneT2cap;
      transRightToVeh = cap2veh * velodyneR2cap;
      
      subLeft = nh.subscribe<sensor_msgs::PointCloud2>(subLeftTopic, 5, &LidarTransform::leftTransformCB, this, ros::TransportHints().tcpNoDelay());
      subRight = nh.subscribe<sensor_msgs::PointCloud2>(subRightTopic, 5, &LidarTransform::rightTransformCB, this, ros::TransportHints().tcpNoDelay());
      subTop = nh.subscribe<sensor_msgs::PointCloud2>(subTopTopic, 5, &LidarTransform::topTransformCB, this, ros::TransportHints().tcpNoDelay());

      pubTop = nh.advertise<sensor_msgs::PointCloud2> (pubTopTopic, 10);
      pubLeft = nh.advertise<sensor_msgs::PointCloud2> (pubLeftTopic, 10);
      pubRight = nh.advertise<sensor_msgs::PointCloud2> (pubRightTopic, 10);

    }

    void getTransformationMatrix(int tfNum, Eigen::Affine3f* matPtr) {
      /*
      gets transformation matrix from rosparam
      tfNum : frame number in configuration file of tf2 package
      */
      ros::NodeHandle tfNode("~");
      std::string tf_name = "tf_" + to_string(tfNum);
      float x, y, z, roll, pitch, yaw;

      tfNode.getParam(tf_name+"/x", x);
      tfNode.getParam(tf_name+"/y", y);
      tfNode.getParam(tf_name+"/z", z);
      tfNode.getParam(tf_name+"/roll", roll);
      tfNode.getParam(tf_name+"/pitch", pitch);
      tfNode.getParam(tf_name+"/yaw", yaw);

      *matPtr = pcl::getTransformation(x, y, z, roll*M_PI/180, pitch*M_PI/180, yaw*M_PI/180);
    }

    void leftTransformCB(const sensor_msgs::PointCloud2ConstPtr& leftLaserMsg)
    {
      pcl::PointCloud<pcl::PointXYZI>::Ptr pclLeft (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::fromROSMsg(*leftLaserMsg, *pclLeft);

      // Transformation
      pcl::PointCloud<pcl::PointXYZI>::Ptr transformed_cloud (new pcl::PointCloud<pcl::PointXYZI> ());

      M_for_l= transLeftToVeh.matrix();
      pcl::transformPointCloud (*pclLeft, *transformed_cloud, M_for_l);
      
      // pcl -> sensor_msg form & publish
      pcl::toROSMsg(*transformed_cloud, pubLsensor);
      pubLsensor.header.frame_id = "vehicle_frame";
      pubLeft.publish(pubLsensor);
    }

    void topTransformCB(const sensor_msgs::PointCloud2ConstPtr& topLaserMsg)
    {
      pcl::PointCloud<pcl::PointXYZI>::Ptr pclTop (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pclTop_filtered (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::fromROSMsg(*topLaserMsg, *pclTop);

      pcl::VoxelGrid<pcl::PointXYZI> sor;
      sor.setInputCloud (pclTop);
      sor.setLeafSize (0.15, 0.15, 0.15);
      sor.filter (*pclTop_filtered);

      // Transformation


      pcl::PointCloud<pcl::PointXYZI>::Ptr transformed_cloud (new pcl::PointCloud<pcl::PointXYZI> ());

      M_for_t= transTopToVeh.matrix();
      pcl::transformPointCloud (*pclTop_filtered, *transformed_cloud, M_for_t);
      
      // pcl -> sensor_msg form & publish
      pcl::toROSMsg(*transformed_cloud, pubTsensor);
      pubTsensor.header.frame_id = "vehicle_frame";
      pubTop.publish(pubTsensor);
    }

    void rightTransformCB(const sensor_msgs::PointCloud2ConstPtr& rightLaserMsg)
    {
      pcl::PointCloud<pcl::PointXYZI>::Ptr pclRight (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::fromROSMsg(*rightLaserMsg, *pclRight);

      M_for_r= transRightToVeh.matrix();
      pcl::PointCloud<pcl::PointXYZI>::Ptr transformed_cloud (new pcl::PointCloud<pcl::PointXYZI> ());

      pcl::transformPointCloud (*pclRight, *transformed_cloud, M_for_r);
      pcl::toROSMsg(*transformed_cloud, pubRsensor);
      pubRsensor.header.frame_id = "vehicle_frame";
      pubRight.publish(pubRsensor);
    }
};

    /*
    void topTransformCB(const sensor_msgs::PointCloud2ConstPtr& topLaserMsg)
    {
      pcl::PointCloud<pcl::PointXYZI>::Ptr pclTop (new pcl::PointCloud<pcl::PointXYZI> ());

      pcl::fromROSMsg(*topLaserMsg, *pclTop);
      pcl::toROSMsg(*pclTop, pubTsensor);
      pubTop.publish(pubTsensor);
    }
    */
    
int main(int argc, char** argv)
{
    ros::init(argc, argv, "transform_node");

    LidarTransform LT;

    ROS_INFO("\033[1;32m----> [AGV Global Module] : Image Projection / MIDDLE LIDAR\033[0m");

    ros::MultiThreadedSpinner spinner(3);
    spinner.spin();

    return 0;
}
