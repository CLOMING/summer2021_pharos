#include "utility.h"
#include <pcl/ModelCoefficients.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/features/normal_3d.h>
#include <pcl/search/kdtree.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Odometry.h>
#include <Eigen/Dense>
#include <tf/transform_listener.h>
#include <sensor_msgs/point_cloud_conversion.h>

double diff_value;
bool isMapInit = false;
std::vector<int> MapInitVector;

nav_msgs::Odometry Odom_;

#define MAP_IDX(sx, i, j) ((sx) * (j) + (i))
nav_msgs::OccupancyGridPtr drivable_map (new nav_msgs::OccupancyGrid);


class Map_Filter {
private:
    ros::NodeHandle nh; 
    ros::NodeHandlePtr pnh;
    
public:
    ros::Subscriber subTotal;
    ros::Subscriber sub_map_topic;
    ros::Subscriber sub_odom_topic;
    ros::Publisher pubFiltered;

    std::string subOusterTopic, map_topic, odom_topic;
    std::string pubOusterFiltered;

    std::string target_frame = "map";
    sensor_msgs::PointCloud2 msg_filtered;


    //static tf::TransformListener listener;

    Map_Filter(){
      Eigen::Affine3f vehicle_tf;


      pnh = ros::NodeHandlePtr(new ros::NodeHandle("~"));
      
      pnh->param<std::string>("subOusterTopic", subOusterTopic, "subOusterTopic");
      pnh->param<std::string>("map_topic", map_topic, "map_topic");
      pnh->param<std::string>("pubOusterFiltered", pubOusterFiltered, "pubOusterFiltered");

      subTotal = nh.subscribe<sensor_msgs::PointCloud2>(subOusterTopic , 10 , &Map_Filter::filtering_Map, this);
      sub_map_topic = nh.subscribe(map_topic , 10 , &Map_Filter::mapCB, this); //called once

      pubFiltered = nh.advertise<sensor_msgs::PointCloud2>(pubOusterFiltered,10);
      
    }

    void mapCB(const nav_msgs::OccupancyGridPtr& map)
    { /// const 빼주니까 grid ptr사이
        isMapInit = true;
        drivable_map = map;

    }


    void filtering_Map(const sensor_msgs::PointCloud2::ConstPtr& totalMsg)
    {   
        if(!isMapInit)
        {
            return;
        }

        pcl::PointCloud<pcl::PointXYZI>::Ptr initial_cloud (new pcl::PointCloud<pcl::PointXYZI>);
        pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_map_frame (new pcl::PointCloud<pcl::PointXYZI>);
        pcl::PointCloud<pcl::PointXYZI>::Ptr filtered_cloud (new pcl::PointCloud<pcl::PointXYZI>);
        pcl::PointCloud<pcl::PointXYZI>::Ptr filtered_on_veh_cloud (new pcl::PointCloud<pcl::PointXYZI>);

        pcl::fromROSMsg(*totalMsg, *initial_cloud);

        // Get tf matrix
        static tf::TransformListener listener;

        tf::StampedTransform transform;
        try {
            //listener.lookupTransform(target_frame, totalMsg->header.frame_id, ros::Time(0), transform);
            listener.lookupTransform(target_frame, "vehicle_frame", ros::Time(0), transform);
        }
        catch (tf::TransformException ex) {
            ROS_ERROR("%s",ex.what());
            return;
        }

        pcl_ros::transformPointCloud(*initial_cloud, *pcl_map_frame, transform);
        //pcl::toROSMsg(*pcl_map_frame, msg_filtered);
        //msg_filtered.header.frame_id = "map";
        //msg_filtered.header.stamp = totalMsg->header.stamp;
        //pubFiltered.publish(msg_filtered);

        double resolutionInverse = 1 / drivable_map->info.resolution;
        
        for(int nIndex=0; nIndex < pcl_map_frame->points.size(); nIndex++){
            if (drivable_map->data.size() != 0) { /// map data가 안들어와 있을때)

                int xIndex, yIndex;
                xIndex = (int) (
                        (pcl_map_frame->points[nIndex].x ) *
                        resolutionInverse); //- drivable_map->info.origin.position.x
                yIndex = (int) (
                        (pcl_map_frame->points[nIndex].y ) * 
                        resolutionInverse); //- drivable_map->info.origin.position.y

                int mapIndex = MAP_IDX(drivable_map->info.width, xIndex, yIndex);

                if(mapIndex < 0)
                {
                    ROS_ERROR(" [PHAROS Perception] PointCloud Divider : Out of map");
                }else{
                    
                int mapdata = drivable_map->data[mapIndex];
                


                if (mapdata == 0) { /// 맵(도로)이랑 일치한 점이 하나라도 나오는 지점.
                    filtered_cloud->points.push_back(pcl_map_frame->points[nIndex]);
                } 
                else {
                }}

            }

            else if(drivable_map->data.size() == 0 && nIndex == 0)
            {              
                ROS_ERROR(" [PHAROS Perception] PointCloud Divider : None TF data available");
            } 
        }
        
        // TF inverse : map -> veh
        pcl_ros::transformPointCloud(*filtered_cloud, *filtered_on_veh_cloud, transform.inverse());

        sensor_msgs::PointCloud2 pubfiltered_pcl;
        pcl::toROSMsg(*filtered_on_veh_cloud, pubfiltered_pcl);
        pubfiltered_pcl.header.frame_id = "vehicle_frame";
        pubfiltered_pcl.header.stamp = totalMsg->header.stamp;
        pubFiltered.publish(pubfiltered_pcl);
        
        
    }    
};


int main(int argc, char** argv)
{
    ros::init(argc, argv, "Map_Filter_node");

    Map_Filter mapfilter;

    ROS_INFO("\033[1;32m----> [PHAROS Perception] PointCloud Map Filter : Initialized\033[0m");

    ros::MultiThreadedSpinner spinner(3);
    spinner.spin();

    return 0;
}
