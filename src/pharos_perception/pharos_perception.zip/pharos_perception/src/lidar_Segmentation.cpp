#include "utility.h"
#include <pcl/ModelCoefficients.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/io/pcd_io.h>

std::string sub_Velodyne_Left_TF, sub_Velodyne_Right_TF, sub_Ouster_mapfiltered, sub_Ouster;
std::string pubTotalLidar, pubSurface, pubObstacle, pubObstacle_perception;
float zSurface, zBoundary;

class LidarSegmentation {
private:
    ros::NodeHandle nh; 
    ros::NodeHandlePtr pnh;
    
public:
    ros::Subscriber subtransformedOuster;
    ros::Subscriber subOuster;
    ros::Publisher pubCombined;
    ros::Publisher pubGround;
    ros::Publisher pubObject;
    ros::Publisher pubObject_percep;
    
    LidarSegmentation(){
      pnh = ros::NodeHandlePtr(new ros::NodeHandle("~"));
      pnh->param<std::string>("sub_Ouster", sub_Ouster, "sub_Ouster");
      pnh->param<std::string>("sub_Ouster_mapfiltered", sub_Ouster_mapfiltered, "sub_Ouster_mapfiltered");
      pnh->param<std::string>("pubTotalLidar", pubTotalLidar, "pubTotalLidar");
      pnh->param<std::string>("pubSurface", pubSurface, "pubSurface");
      pnh->param<std::string>("pubObstacle", pubObstacle, "pubObstacle");
      pnh->param<std::string>("pubObstacle_perception", pubObstacle_perception, "pubObstacle_perception");
      pnh->param<float>("zSurface", zSurface, 0.0);
      pnh->param<float>("zBoundary", zBoundary, 0.0);
    
      subtransformedOuster = nh.subscribe<sensor_msgs::PointCloud2>(sub_Ouster_mapfiltered, 5, &LidarSegmentation::detectSurfacePoints, this, ros::TransportHints().tcpNoDelay());
      subOuster = nh.subscribe<sensor_msgs::PointCloud2>(sub_Ouster, 5, &LidarSegmentation::detectSurfacePointsformcl, this, ros::TransportHints().tcpNoDelay());

      pubGround = nh.advertise<sensor_msgs::PointCloud2> (pubSurface, 10);
      pubObject_percep = nh.advertise<sensor_msgs::PointCloud2> (pubObstacle_perception, 10);
      pubObject = nh.advertise<sensor_msgs::PointCloud2> (pubObstacle, 10);
    }


    void detectSurfacePoints(const sensor_msgs::PointCloud2ConstPtr& total_msg) {

      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_total (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_total_2 (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_plane (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object_1 (new pcl::PointCloud<pcl::PointXYZI> ());
      // get points satisfying zLower < z < zUpper       
      pcl::PointCloud<pcl::PointXYZI>::Ptr ground_cand(new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr non_ground(new pcl::PointCloud<pcl::PointXYZI> ());
            
      pcl::fromROSMsg(*total_msg, *pcl_total);

      pcl::CropBox<pcl::PointXYZI> boxFilter;
      boxFilter.setMin(Eigen::Vector4f(-1, -1.5, 0, 1.0));
      boxFilter.setMax(Eigen::Vector4f(4, 1.5, 2.5, 1.0));
      boxFilter.setInputCloud(pcl_total);
      boxFilter.setNegative(true);
      boxFilter.filter(*pcl_total_2);

      pcl::PassThrough<pcl::PointXYZI> pass;
      pass.setInputCloud (pcl_total_2);                                       //입력
      pass.setFilterFieldName ("z");                                          //적용할 좌표 축 (eg. Z축)
      pass.setFilterLimits(zSurface-zBoundary, zSurface+zBoundary);           //적용할 값 (최소, 최대 값)
      pass.filter(*ground_cand);
      
      pass.setNegative(true);
      pass.filter(*non_ground);
      
      // RANSAC - get indices of inliers
      pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients);
      pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
      pcl::SACSegmentation<pcl::PointXYZI> seg;
      
      seg.setOptimizeCoefficients (true);
      seg.setModelType (pcl::SACMODEL_PLANE);
      seg.setMethodType (pcl::SAC_RANSAC);
      seg.setDistanceThreshold (0.3);
      seg.setInputCloud (ground_cand);
      seg.segment (*inliers, *coefficients);
      
      // filter inliers among ground candidates
      pcl::copyPointCloud<pcl::PointXYZI>(*ground_cand, *inliers, *pcl_plane);
      
      // ground candidates but outliers
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_outlier (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::ExtractIndices<pcl::PointXYZI> extract;
      
      extract.setInputCloud(ground_cand);
      extract.setIndices(inliers);
      extract.setNegative(true);
      extract.filter(*pcl_outlier);
       
      // obtain object pointclouds
      *pcl_object += *non_ground;
      *pcl_object += *pcl_outlier;

      pcl::PassThrough<pcl::PointXYZI> boxfilterNEW;
      boxfilterNEW.setInputCloud (pcl_object);
      boxfilterNEW.setFilterFieldName ("y");
      boxfilterNEW.setFilterLimits (-10.0, 10.0);
      boxfilterNEW.filter (*pcl_object_1);
      
      sensor_msgs::PointCloud2 pubGroundMsg;
      sensor_msgs::PointCloud2 pubObjectMsg;
      
      pcl::toROSMsg(*pcl_object_1, pubObjectMsg);
      pubObjectMsg.header.frame_id = "vehicle_frame";
      pubObject_percep.publish(pubObjectMsg);
    }

    void detectSurfacePointsformcl(const sensor_msgs::PointCloud2ConstPtr& total_msg) {

      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_total (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_total_2 (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_plane (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_object_1 (new pcl::PointCloud<pcl::PointXYZI> ());
      // get points satisfying zLower < z < zUpper       
      pcl::PointCloud<pcl::PointXYZI>::Ptr ground_cand(new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::PointCloud<pcl::PointXYZI>::Ptr non_ground(new pcl::PointCloud<pcl::PointXYZI> ());
            
      pcl::fromROSMsg(*total_msg, *pcl_total);

      pcl::CropBox<pcl::PointXYZI> boxFilter;
      boxFilter.setMin(Eigen::Vector4f(-1, -1.5, 0, 1.0));
      boxFilter.setMax(Eigen::Vector4f(4, 1.5, 2.5, 1.0));
      boxFilter.setInputCloud(pcl_total);
      boxFilter.setNegative(true);
      boxFilter.filter(*pcl_total_2);

      pcl::PassThrough<pcl::PointXYZI> pass;
      pass.setInputCloud (pcl_total_2);                                       //입력
      pass.setFilterFieldName ("z");                                          //적용할 좌표 축 (eg. Z축)
      pass.setFilterLimits(zSurface-zBoundary, zSurface+zBoundary);           //적용할 값 (최소, 최대 값)
      pass.filter(*ground_cand);
      
      pass.setNegative(true);
      pass.filter(*non_ground);
      
      // RANSAC - get indices of inliers
      pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients);
      pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
      pcl::SACSegmentation<pcl::PointXYZI> seg;
      
      seg.setOptimizeCoefficients (true);
      seg.setModelType (pcl::SACMODEL_PLANE);
      seg.setMethodType (pcl::SAC_RANSAC);
      seg.setDistanceThreshold (0.3);
      seg.setInputCloud (ground_cand);
      seg.segment (*inliers, *coefficients);
      
      // filter inliers among ground candidates
      pcl::copyPointCloud<pcl::PointXYZI>(*ground_cand, *inliers, *pcl_plane);
      
      // ground candidates but outliers
      pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_outlier (new pcl::PointCloud<pcl::PointXYZI> ());
      pcl::ExtractIndices<pcl::PointXYZI> extract;
      
      extract.setInputCloud(ground_cand);
      extract.setIndices(inliers);
      extract.setNegative(true);
      extract.filter(*pcl_outlier);
       
      // obtain object pointclouds
      *pcl_object += *non_ground;
      *pcl_object += *pcl_outlier;

      pcl::PassThrough<pcl::PointXYZI> boxfilterNEW;
      boxfilterNEW.setInputCloud (pcl_object);
      boxfilterNEW.setFilterFieldName ("y");
      boxfilterNEW.setFilterLimits (-10.0, 10.0);
      boxfilterNEW.filter (*pcl_object_1);
      
      sensor_msgs::PointCloud2 pubGroundMsg;
      sensor_msgs::PointCloud2 pubObjectMsg;
      
      pcl::toROSMsg(*pcl_object_1, pubObjectMsg);
      pubObjectMsg.header.frame_id = "vehicle_frame";
      pubObject.publish(pubObjectMsg);
      
      pcl::toROSMsg(*pcl_plane, pubGroundMsg);
      pubGroundMsg.header.frame_id = "vehicle_frame";
      pubGround.publish(pubGroundMsg);
      
    }

    
};


int main(int argc, char** argv)
{
    ros::init(argc, argv, "lidarseg_node");

    LidarSegmentation lidarseg;

    ROS_INFO("\033[1;32m----> [PHAROS Perception] PointCloud Divider : Initialized\033[0m");

    ros::MultiThreadedSpinner spinner(10);
    spinner.spin();

    return 0;
}
