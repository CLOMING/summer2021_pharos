#ifndef	ASN1FIX_INTEGER_H
#define	ASN1FIX_INTEGER_H

/* Type1 ::= INTEGER { a(1), b(2) } */
int asn1f_fix_integer(arg_t *);

#endif	/* ASN1FIX_INTEGER_H */
