#ifndef	ASN1FIX_BIT_STRING_H
#define	ASN1FIX_BIT_STRING_H

int asn1f_fix_bit_string(arg_t *);

#endif	/* ASN1FIX_BIT_STRING_H */
