#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <assert.h>
#include <time.h>

#define ROS_INTERVAL 50 // 50ms
#define PAUSE 10000 // 10m

class ROS_to_OBU {
private:
    ros::NodeHandle nh; 
    ros::NodeHandlePtr pnh;
    
public:
    ros::Subscriber subPVD;
    

    ROS_to_OBU(){
      


      pnh = ros::NodeHandlePtr(new ros::NodeHandle("~"));
      
      typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::NavSatFix, ublox_msgs::NavPVT, pharos_msgs::CAN_GWAY_header> SyncPolicy;
      message_filters::Subscriber<sensor_msgs::NavSatFix> *sub1_ ;
      message_filters::Subscriber<ublox_msgs::NavPVT> *sub2_ ;
      message_filters::Subscriber<pharos_msgs::CAN_GWAY_header> *sub3_ ;
      message_filters::Synchronizer<SyncPolicy>* sync_;
      sub1_ = new message_filters::Subscriber<sensor_msgs::NavSatFix>(nh, /ublox/fix, 1);
      sub2_ = new message_filters::Subscriber<ublox_msgs::NavPVT>(nh, /ublox/navpvt, 1);
      sub3_ = new message_filters::Subscriber<pharos_msgs::CAN_GWAY_header>(nh, /CAN_Gateway, 1);
      sync_ = new message_filters::Synchronizer<SyncPolicy>(SyncPolicy(10), *sub1_, *sub2_, *sub3_);
      sync_->registerCallback(boost::bind(&ROS_to_OBU::pvd_CB, this, _1, _2, _3));
      
    }

    void pvd_CB(const sensor_msgs::NavSatFix fixmsg, const ublox_msgs::NavPVT navpvtmsg, const pharos_msgs::CAN_GWAY_header canmsg)
    { 



    }


       
};


int main(int argc, char** argv)
{
    ros::init(argc, argv, "ROStoOBU_node");

    ROS_to_OBU ros2obu;

    //ROS_INFO("\033[1;32m----> [PHAROS Perception] PointCloud Map Filter : Initialized\033[0m");

    ros::MultiThreadedSpinner spinner(3);
    spinner.spin();

    return 0;
}
